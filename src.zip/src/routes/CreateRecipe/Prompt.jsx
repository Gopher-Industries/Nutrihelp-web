import React from 'react'

// Prompt to be used in the Create Recipe page
const Prompt = (props) => (
    <div>
        <p>{props.text}</p>
    </div>
)

export default Prompt